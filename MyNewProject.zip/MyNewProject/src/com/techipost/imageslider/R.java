package com.techipost.imageslider;

public class R {

}
